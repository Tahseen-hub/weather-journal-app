/* Global Variables */

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = (d.getMonth() + 1) +'/'+ d.getDate()+'/'+ d.getFullYear();
let newTime = d.getHours()+':'+ d.getMinutes();


const baseURL = '"http://api.openweathermap.org/data/2.5/weather?units=imperial&zip="'


const APIKey = '&APPID=b6596d3bb84afbf486162a817361d808';

// Event listener to add function to existing  HTML DOM element
document.getElementById('generate').addEventListener('click', performAction);



  function performAction(e){
      const newZip =  document.getElementById('zip').value;
      let zip = newZip + ',us';

      const feelings = document.getElementById('feelings').value;

      weatherEntry(baseURL, zip, APIKey)

      .then(function(data){

          postData('/add', {  temp: data.main.temp, 
                              desc: data.weather[0].description,
                              name: data.name,
                              feelings: feelings,
                              date: newDate,
                              time: newTime

                          }                                
                  );
        })
        .then(function(data){
            
          updateUI()
            }
        )
        
  }


//get API data
const weatherEntry = async (baseURL, zip, key)=>{

    const res = await fetch(baseURL+zip+key)
    try {
  
      const weatherUpdate = await res.json();
      console.log(weatherUpdate)
        
      return weatherUpdate;
    }  catch(error) {
      console.log("error", error);
      // appropriately handle the error
    }

};


//store the api data
const postData = async ( url = '', data = {})=>{

    const response = await fetch(url, {
    method: 'POST', 
    credentials: 'same-origin', 
    headers: {
        'Content-Type': 'application/json',
    },
	// body data type must match "Content-Type" header
    body: JSON.stringify(data),         
  });
  try {
    const newData = await response.json();
    return newData;
  }catch(error) {
  console.log("error", error)
  }
}



//update page content with recent entries
const updateUI = async () => {
    const request = await fetch('/all');
    try{
      const allData = await request.json();
      console.log(allData);

      document.getElementById('entry-logs').innerHTML = "";

      for (let i = allData.length - 1; i >= 0; i--) {
       
            let oldEntry = document.createElement('div');
            let oldTitle = document.createElement('h3');
            let oldContent = document.createElement('p');

            oldEntry.setAttribute('class', 'prev-entry');

            oldTitle.setAttribute('class', 'prev-title');
			// to convert from kelvin to celsius
            let farTemp = (allData[i].temp - 273.15) * 9/5 + 32;
            let roundTemp = Math.round(farTemp);
            oldTitle.innerHTML = allData[i].date + ' at ' + allData[i].time + ' -> It was ' + roundTemp + '&deg in ' + allData[i].name + ', with ' + allData[i].desc;

            document.getElementById('entry-logs').append(oldTitle);           
            document.getElementById('entry-logs').append(oldEntry);

         
            oldContent.setAttribute('class', 'prev-content');
            oldContent.innerHTML = allData[i].feelings;

            oldEntry.append(oldContent);

        }

        return allData;
    }catch(error){
      console.log("error", error);
    }
  }
  

  