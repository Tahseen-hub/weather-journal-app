# Weather-Journal App Project

## Overview
This project is for creating an asynchronous web app that uses Web API and user data to dynamically update the UI. 

## Instructions
I modified the `server.js` file and the `website/app.js` file. 
a littil modification applied on  `index.html` 
also `style.css` ahs been modified to style the application to customized perfection.

